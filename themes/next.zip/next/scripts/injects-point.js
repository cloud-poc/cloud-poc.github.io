'use strict';

module.exports = {
  views: ['head', 'header', 'sidebar', 'postMeta', 'postBodyEnd', 'footer', 'bodyEnd'],
  styles: ['variable', 'mixin', 'style']
};
